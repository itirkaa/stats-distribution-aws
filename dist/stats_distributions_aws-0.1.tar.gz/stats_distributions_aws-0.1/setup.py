from setuptools import setup

setup(name='stats_distributions_aws',
      version='0.1',
      description='Gaussian Distributions',
      packages=['stats_distributions_aws'],
      zip_safe=False)
