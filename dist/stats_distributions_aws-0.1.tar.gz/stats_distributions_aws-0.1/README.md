# STAT-DISTRIBUTIONS
This package was build under guided project based course by AWS at Udacity.
The package is for calculating and visualizing Gaussian and Binomial Probability distribution.

